# Vikas Kumar Singh - Academic Website

Static academic website prepared for GitHub Pages.

## Repository target

`https://vksgpb.github.io/vikas/`

The easiest setup is a public GitHub repository named `vikas` under the GitHub account `vksgpb`.

## Files

- `index.html` - website content and structure
- `styles.css` - responsive visual design
- `script.js` - mobile navigation, section highlighting and light scroll animation
- `assets/profile.jpg` - portrait
- `assets/wheat-lab.jpg` - hero research image
- `assets/Vikas_Kumar_Singh_CV.docx` - downloadable CV
- `assets/favicon.svg` - browser icon
- `.nojekyll` - tells GitHub Pages to serve the site as plain static files
- `robots.txt` and `sitemap.xml` - basic search-engine support

## Publish with GitHub Pages

1. Create a public repository called `vikas` under `vksgpb`.
2. Upload all files and folders from this package to the repository root.
3. In GitHub, open **Settings > Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. After deployment, the site should be available at `https://vksgpb.github.io/vikas/`.

## Updating the website

Edit `index.html` for text, publications and links. Replace files in `assets/` when updating the CV or photographs. Keep the same filenames if you want existing links to continue working.
